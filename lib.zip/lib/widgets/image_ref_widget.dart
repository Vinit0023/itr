import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import '../services/storage_service.dart';

/// Shows an image from an [ImageRef].
/// - On web: uses memory bytes
/// - On mobile: uses File path
/// Supports cacheWidth for performance.
class ImageRefWidget extends StatefulWidget {
  final ImageRef ref;
  final BoxFit fit;
  final int? cacheWidth;
  final Widget? placeholder;

  const ImageRefWidget({
    super.key,
    required this.ref,
    this.fit = BoxFit.cover,
    this.cacheWidth,
    this.placeholder,
  });

  @override
  State<ImageRefWidget> createState() => _ImageRefWidgetState();
}

class _ImageRefWidgetState extends State<ImageRefWidget> {
  Uint8List? _bytes;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(covariant ImageRefWidget old) {
    super.didUpdateWidget(old);
    if (old.ref.id != widget.ref.id) _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    if (widget.ref.bytes != null) {
      _bytes = widget.ref.bytes;
    } else if (kIsWeb) {
      _bytes = await StorageService().readBytes(widget.ref);
    }
    if (mounted) setState(() => _loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return widget.placeholder ??
          const Center(child: CircularProgressIndicator(strokeWidth: 2));
    }

    // Web or mobile with in-memory bytes
    if (_bytes != null) {
      return Image.memory(
        _bytes!,
        fit: widget.fit,
        cacheWidth: widget.cacheWidth,
        errorBuilder: (_, __, ___) => _errorWidget(),
      );
    }

    // Mobile — use file path
    if (!kIsWeb && widget.ref.path != null) {
      return Image.file(
        File(widget.ref.path!),
        fit: widget.fit,
        cacheWidth: widget.cacheWidth,
        key: ValueKey(widget.ref.path),
        errorBuilder: (_, __, ___) => _errorWidget(),
      );
    }

    return _errorWidget();
  }

  Widget _errorWidget() => Container(
        color: Colors.grey[900],
        child: const Icon(Icons.broken_image_outlined, color: Colors.grey),
      );
}
