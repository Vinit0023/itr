import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/foundation.dart' show kIsWeb, ChangeNotifier, debugPrint;
import '../services/storage_service.dart';
import '../services/share_service.dart';
import '../services/image_processor.dart';
import '../services/gallery_service.dart';
import '../services/text_recognizer_service.dart';

class AppState extends ChangeNotifier {
  final _storage        = StorageService();
  final _shareService   = ShareService();
  final _imageProcessor = ImageProcessor();
  final _galleryService = GalleryService();
  final _textRecognizer = TextRecognizerService();

  final List<ImageRef> _receivedImages  = [];
  List<ImageRef> _processedImages = [];
  List<ImageRef> _selectedImages  = [];
  List<String>   _albums          = [];

  bool   _isLoading       = false;
  double _processProgress = 0.0;

  List<ImageRef> get receivedImages  => _receivedImages;
  List<ImageRef> get processedImages => _processedImages;
  List<ImageRef> get selectedImages  => _selectedImages;
  List<String>   get albums          => _albums;
  bool           get isLoading       => _isLoading;
  double         get processProgress => _processProgress;

  AppState() { _init(); }

  Future<void> _init() async {
    _shareService.onImagesReceived = (refs) {
      _receivedImages.insertAll(0, refs);
      notifyListeners();
    };
    _shareService.init();
    _processedImages = _storage.getProcessedImages();
    _albums          = _storage.getAlbums();
    notifyListeners();
  }

  // ── Selection ─────────────────────────────────────────────────

  void toggleSelection(ImageRef image) {
    if (_selectedImages.contains(image)) {
      _selectedImages.remove(image);
    } else {
      _selectedImages.add(image);
    }
    notifyListeners();
  }

  void clearSelection() {
    _selectedImages.clear();
    notifyListeners();
  }

  void selectAllRecent() {
    _selectedImages = List.from(_receivedImages);
    notifyListeners();
  }

  // ── Pick images ───────────────────────────────────────────────

  Future<void> pickFromGallery() async {
    final picked = await _galleryService.pickImages();
    if (picked.isEmpty) return;

    final refs = picked
        .map((p) => ImageRef(
              id: DateTime.now().millisecondsSinceEpoch.toString() + p.name,
              path: p.path,
              bytes: p.bytes,
              name: p.name,
            ))
        .toList();

    _receivedImages.insertAll(0, refs);
    _selectedImages.addAll(refs);
    notifyListeners();
  }

  // ── Get bytes for display ─────────────────────────────────────

  Future<Uint8List?> getBytesForRef(ImageRef ref) async {
    if (ref.bytes != null) return ref.bytes;
    return _storage.readBytes(ref);
  }

  // ── Batch process (draw mask) ─────────────────────────────────

  Future<List<ImageRef>> batchProcess({
    List<EraseRegion> regions = const [],
    List<ErasePath>   paths   = const [],
  }) async {
    if (_selectedImages.isEmpty || (regions.isEmpty && paths.isEmpty)) return [];

    _isLoading       = true;
    _processProgress = 0.0;
    notifyListeners();

    final results = await _imageProcessor.batchErase(
      _selectedImages,
      regions: regions,
      paths:   paths,
      onProgress: (p) {
        _processProgress = p;
        notifyListeners();
      },
    );

    for (final ref in results) { _storage.addProcessed(ref); }
    _processedImages = _storage.getProcessedImages();
    _selectedImages  = List.from(results);
    _isLoading       = false;
    _processProgress = 1.0;
    notifyListeners();

    return results;
  }

  // ── Auto erase text ───────────────────────────────────────────

  Future<List<ImageRef>> autoSearchAndErase(String searchText) async {
    if (_selectedImages.isEmpty || searchText.trim().isEmpty) return [];

    _isLoading       = true;
    _processProgress = 0.0;
    notifyListeners();

    final List<ImageRef> finalResults = [];

    for (int i = 0; i < _selectedImages.length; i++) {
      final ref   = _selectedImages[i];
      final bytes = await getBytesForRef(ref);

      List<Map<String, double>> foundBoxes = [];

      if (!kIsWeb && bytes != null && ref.path != null) {
        try {
          int imgW = 0;
          int imgH = 0;
          try {
            final codec = await ui.instantiateImageCodec(bytes);
            final frameInfo = await codec.getNextFrame();
            imgW = frameInfo.image.width;
            imgH = frameInfo.image.height;
          } catch (e) {
            debugPrint('Failed to decode image dimensions: $e');
          }

          if (imgW > 0 && imgH > 0) {
            foundBoxes = await _textRecognizer.findTextRegions(
              ref.path,
              bytes,
              searchText,
              imgW,
              imgH,
            );
          }
        } catch (e) {
          debugPrint('TextRecognizer: $e');
        }
      }

      if (foundBoxes.isNotEmpty) {
        final regions = foundBoxes
            .map((b) => EraseRegion(
                  xPercent: b['xPercent']!,
                  yPercent: b['yPercent']!,
                  wPercent: b['wPercent']!,
                  hPercent: b['hPercent']!,
                ))
            .toList();
        final result = await _imageProcessor.batchErase([ref], regions: regions);
        finalResults.addAll(result);
      } else {
        finalResults.add(ref);
      }

      _processProgress = (i + 1) / _selectedImages.length;
      notifyListeners();
    }

    for (final ref in finalResults) { _storage.addProcessed(ref); }
    _processedImages = _storage.getProcessedImages();
    _selectedImages  = List.from(finalResults);
    _isLoading       = false;
    _processProgress = 1.0;
    notifyListeners();

    return finalResults;
  }

  // ── Albums ────────────────────────────────────────────────────

  Future<void> saveToAlbum(String albumName) async {
    if (_selectedImages.isEmpty) return;
    await _storage.saveToAlbum(albumName, _selectedImages);
    _albums = _storage.getAlbums();
    notifyListeners();
  }

  List<ImageRef> getAlbumImages(String albumName) =>
      _storage.getAlbumImages(albumName);

  Future<void> deleteAlbum(String albumName) async {
    await _storage.deleteAlbum(albumName);
    _albums = _storage.getAlbums();
    notifyListeners();
  }

  // ── Save / download ───────────────────────────────────────────

  Future<bool> saveAllToGallery() async {
    if (_selectedImages.isEmpty) return false;
    return _storage.saveToGallery(_selectedImages);
  }

  // ── Delete ────────────────────────────────────────────────────

  void deleteProcessedImage(ImageRef ref) {
    _storage.deleteProcessed(ref);
    _processedImages = _storage.getProcessedImages();
    notifyListeners();
  }

  Future<void> clearAllProcessed() async {
    _storage.clearAllProcessed();
    _processedImages = [];
    notifyListeners();
  }

  @override
  void dispose() {
    _shareService.dispose();
    _imageProcessor.dispose();
    _textRecognizer.dispose();
    super.dispose();
  }
}
