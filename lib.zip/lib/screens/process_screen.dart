import 'dart:io';
import 'dart:math';
import 'dart:ui' show PointMode;
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image/image.dart' as img;
import '../state/app_state.dart';
import '../services/image_processor.dart';
import '../theme/app_theme.dart';

class ProcessScreen extends StatefulWidget {
  const ProcessScreen({super.key});

  @override
  State<ProcessScreen> createState() => _ProcessScreenState();
}

class _Stroke {
  final List<Offset> points;
  final double brushSize;
  _Stroke({required this.points, required this.brushSize});
}

class _ProcessScreenState extends State<ProcessScreen> {
  final TransformationController _transformController = TransformationController();

  bool _isDrawMode = true;
  double _brushSize = 22.0;

  final List<_Stroke> _strokes = [];
  _Stroke? _currentStroke;

  // Use a GlobalKey on the image container — not the Stack — to fix the crash
  final GlobalKey _containerKey = GlobalKey();
  Size? _containerSize;
  double? _aspectRatio;
  bool _imageReady = false;

  @override
  void initState() {
    super.initState();
    _loadAspectRatio();
  }

  Future<void> _loadAspectRatio() async {
    final state = Provider.of<AppState>(context, listen: false);
    if (state.selectedImages.isNotEmpty) {
      try {
        final ref = state.selectedImages.first;
        final bytes = ref.bytes ?? await state.getBytesForRef(ref);
        if (bytes == null) return;
        final decoded = img.decodeImage(bytes);
        if (decoded != null && mounted) {
          setState(() {
            _aspectRatio = decoded.width / decoded.height;
            _imageReady = true;
          });
          // Measure size after frame is drawn
          WidgetsBinding.instance.addPostFrameCallback((_) => _measureContainer());
        }
      } catch (_) {}
    }
  }

  void _measureContainer() {
    final ctx = _containerKey.currentContext;
    if (ctx == null) return;
    final box = ctx.findRenderObject() as RenderBox?;
    if (box == null || !box.hasSize) return;
    setState(() => _containerSize = box.size);
  }

  // Pan gesture handlers
  void _onPanStart(DragStartDetails d) {
    if (!_isDrawMode) return;
    final pos = _localPosition(d.globalPosition);
    if (pos == null) return;
    setState(() => _currentStroke = _Stroke(points: [pos], brushSize: _brushSize));
  }

  void _onPanUpdate(DragUpdateDetails d) {
    if (!_isDrawMode || _currentStroke == null) return;
    final pos = _localPosition(d.globalPosition);
    if (pos == null) return;
    setState(() => _currentStroke!.points.add(pos));
  }

  void _onPanEnd(DragEndDetails _) {
    if (!_isDrawMode || _currentStroke == null) return;
    setState(() {
      _strokes.add(_currentStroke!);
      _currentStroke = null;
    });
  }

  Offset? _localPosition(Offset globalPos) {
    final ctx = _containerKey.currentContext;
    if (ctx == null) return null;
    final box = ctx.findRenderObject() as RenderBox?;
    if (box == null || !box.hasSize) return null;
    return box.globalToLocal(globalPos);
  }

  Widget _buildFirstImage(AppState state) {
    final ref = state.selectedImages.first;
    if (ref.bytes != null) {
      return Image.memory(
        ref.bytes!,
        fit: BoxFit.fill,
        width: double.infinity,
        height: double.infinity,
      );
    }
    if (!kIsWeb && ref.path != null) {
      return Image.file(
        File(ref.path!),
        fit: BoxFit.fill,
        width: double.infinity,
        height: double.infinity,
      );
    }
    return const Center(child: Icon(Icons.image_not_supported_outlined));
  }

  Future<void> _handleProcess() async {
    if (_strokes.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Draw over the areas you want to erase')),
      );
      return;
    }

    final messenger = ScaffoldMessenger.of(context);
    final state     = Provider.of<AppState>(context, listen: false);
    final navigator = Navigator.of(context);

    // Measure just before processing to ensure fresh size
    _measureContainer();
    await Future.delayed(const Duration(milliseconds: 50));

    if (_containerSize == null) {
      messenger.showSnackBar(
        const SnackBar(content: Text('Image not ready yet. Please wait.')),
      );
      return;
    }

    final List<ErasePath> erasePaths = _strokes.map((stroke) {
      final maxDim = max(_containerSize!.width, _containerSize!.height);
      return ErasePath(
        brushSizePercent: stroke.brushSize / maxDim,
        points: stroke.points
            .map((p) => Point<double>(
                  (p.dx / _containerSize!.width).clamp(0.0, 1.0),
                  (p.dy / _containerSize!.height).clamp(0.0, 1.0),
                ))
            .toList(),
      );
    }).toList();

    imageCache.clear();
    imageCache.clearLiveImages();

    await state.batchProcess(paths: erasePaths);

    if (mounted) {
      navigator.pushReplacementNamed('/preview');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgDeep,
      body: Consumer<AppState>(
        builder: (context, state, _) {
          if (state.isLoading) {
            return _LoadingView(progress: state.processProgress);
          }

          if (state.selectedImages.isEmpty) {
            return const Center(child: Text('No images selected'));
          }

          return Column(
            children: [
              // ── App Bar ──────────────────────────────────────
              SafeArea(
                bottom: false,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                  child: Row(
                    children: [
                      IconButton(
                        icon: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: AppTheme.cardBg,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: AppTheme.cardBorder),
                          ),
                          child: const Icon(Icons.arrow_back_ios_new, size: 16),
                        ),
                        onPressed: () => Navigator.pop(context),
                      ),
                      const SizedBox(width: 8),
                      Text('Draw & Erase', style: Theme.of(context).textTheme.titleLarge),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 12),

              // ── Tool Bar ─────────────────────────────────────
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    // Draw / Pan toggle
                    Container(
                      decoration: BoxDecoration(
                        color: AppTheme.cardBg,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppTheme.cardBorder),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          _ToolButton(
                            icon: Icons.pan_tool_outlined,
                            label: 'Pan',
                            active: !_isDrawMode,
                            onTap: () => setState(() => _isDrawMode = false),
                          ),
                          Container(width: 1, height: 32, color: AppTheme.cardBorder),
                          _ToolButton(
                            icon: Icons.brush_outlined,
                            label: 'Draw',
                            active: _isDrawMode,
                            onTap: () => setState(() => _isDrawMode = true),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    // Brush size
                    Expanded(
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                          color: AppTheme.cardBg,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppTheme.cardBorder),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.circle, size: 6, color: AppTheme.textMuted),
                            Expanded(
                              child: Slider(
                                value: _brushSize,
                                min: 5,
                                max: 80,
                                activeColor: AppTheme.crimson,
                                inactiveColor: AppTheme.cardBorder,
                                onChanged: _isDrawMode
                                    ? (v) => setState(() => _brushSize = v)
                                    : null,
                              ),
                            ),
                            const Icon(Icons.circle, size: 20, color: AppTheme.textMuted),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 12),

              // ── Drawing Canvas ────────────────────────────────
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Container(
                    decoration: BoxDecoration(
                      color: AppTheme.cardBg,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: AppTheme.cardBorder),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(20),
                      child: !_imageReady
                          ? const Center(child: CircularProgressIndicator())
                          : InteractiveViewer(
                              transformationController: _transformController,
                              panEnabled: !_isDrawMode,
                              scaleEnabled: !_isDrawMode,
                              minScale: 0.5,
                              maxScale: 5.0,
                              child: Center(
                                child: AspectRatio(
                                  aspectRatio: _aspectRatio!,
                                  child: GestureDetector(
                                    onPanStart: _onPanStart,
                                    onPanUpdate: _onPanUpdate,
                                    onPanEnd: _onPanEnd,
                                    child: Stack(
                                      key: _containerKey,
                                      fit: StackFit.expand,
                                      children: [
                                        _buildFirstImage(state),
                                        if (_containerSize != null)
                                          Positioned.fill(
                                            child: CustomPaint(
                                              painter: _MaskPainter(
                                                strokes: _strokes,
                                                currentStroke: _currentStroke,
                                              ),
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ),
                    ),
                  ),
                ),
              ),

              // ── Action Bar ────────────────────────────────────
              Container(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                decoration: BoxDecoration(
                  color: AppTheme.bgSurface,
                  border: Border(top: BorderSide(color: AppTheme.cardBorder)),
                ),
                child: SafeArea(
                  top: false,
                  child: Row(
                    children: [
                      // Undo
                      _ActionIconButton(
                        icon: Icons.undo,
                        color: AppTheme.textSecondary,
                        onTap: _strokes.isEmpty
                            ? null
                            : () => setState(() => _strokes.removeLast()),
                      ),
                      const SizedBox(width: 8),
                      // Clear all
                      _ActionIconButton(
                        icon: Icons.delete_outline,
                        color: Colors.redAccent,
                        onTap: _strokes.isEmpty
                            ? null
                            : () => setState(() => _strokes.clear()),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _strokes.isEmpty ? null : _handleProcess,
                          icon: const Icon(Icons.auto_fix_high, size: 18),
                          label: const Text('Erase Selection'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppTheme.crimson,
                            disabledBackgroundColor: AppTheme.cardBg,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

// ── Sub-widgets ───────────────────────────────────────────────────

class _LoadingView extends StatelessWidget {
  final double progress;
  const _LoadingView({required this.progress});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 80,
              height: 80,
              child: CircularProgressIndicator(
                value: progress,
                strokeWidth: 6,
                backgroundColor: AppTheme.cardBorder,
                valueColor: AlwaysStoppedAnimation(AppTheme.crimson),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'AI Erasing...',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              '${(progress * 100).toInt()}% complete',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            const SizedBox(height: 24),
            LinearProgressIndicator(
              value: progress,
              backgroundColor: AppTheme.cardBorder,
              valueColor: AlwaysStoppedAnimation(AppTheme.crimson),
              borderRadius: BorderRadius.circular(4),
            ),
          ],
        ),
      ),
    );
  }
}

class _ToolButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  const _ToolButton({
    required this.icon,
    required this.label,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
          color: active ? AppTheme.crimson.withValues(alpha: 0.15) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 18, color: active ? AppTheme.roseGlow : AppTheme.textMuted),
            const SizedBox(width: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 12,
                color: active ? AppTheme.roseGlow : AppTheme.textMuted,
                fontWeight: active ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionIconButton extends StatelessWidget {
  final IconData icon;
  final Color color;
  final VoidCallback? onTap;

  const _ActionIconButton({
    required this.icon,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: onTap == null
              ? AppTheme.cardBg.withValues(alpha: 0.5)
              : AppTheme.cardBg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppTheme.cardBorder),
        ),
        child: Icon(
          icon,
          color: onTap == null ? AppTheme.textMuted : color,
          size: 22,
        ),
      ),
    );
  }
}

// ── Mask Painter ──────────────────────────────────────────────────

class _MaskPainter extends CustomPainter {
  final List<_Stroke> strokes;
  final _Stroke? currentStroke;

  _MaskPainter({required this.strokes, this.currentStroke});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppTheme.roseGlow.withValues(alpha: 0.55)
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..style = PaintingStyle.stroke;

    for (final stroke in strokes) {
      paint.strokeWidth = stroke.brushSize * 2;
      _drawStroke(canvas, stroke, paint);
    }

    if (currentStroke != null) {
      paint.strokeWidth = currentStroke!.brushSize * 2;
      _drawStroke(canvas, currentStroke!, paint);
    }
  }

  void _drawStroke(Canvas canvas, _Stroke stroke, Paint paint) {
    if (stroke.points.isEmpty) return;
    if (stroke.points.length == 1) {
      canvas.drawPoints(PointMode.points, stroke.points, paint);
      return;
    }
    final path = Path();
    path.moveTo(stroke.points.first.dx, stroke.points.first.dy);
    for (int i = 1; i < stroke.points.length; i++) {
      path.lineTo(stroke.points[i].dx, stroke.points[i].dy);
    }
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant _MaskPainter old) => true;
}
