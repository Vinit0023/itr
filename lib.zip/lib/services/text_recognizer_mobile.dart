// Mobile implementation using Google ML Kit
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';

final _recognizer = TextRecognizer(script: TextRecognitionScript.latin);

Future<List<Map<String, double>>> findTextRegions(
  dynamic imageSource,
  Uint8List imageBytes,
  String searchText,
  int imgWidth,
  int imgHeight,
) async {
  if (searchText.trim().isEmpty) return [];

  try {
    final InputImage inputImage;
    if (imageSource is String) {
      inputImage = InputImage.fromFilePath(imageSource);
    } else if (imageSource is File) {
      inputImage = InputImage.fromFile(imageSource);
    } else {
      return [];
    }

    final recognized = await _recognizer.processImage(inputImage);
    final searchLower = searchText.trim().toLowerCase();
    final List<Map<String, double>> found = [];

    for (final block in recognized.blocks) {
      for (final line in block.lines) {
        if (line.text.toLowerCase().contains(searchLower)) {
          for (final element in line.elements) {
            if (element.text.toLowerCase().contains(searchLower) ||
                searchLower.contains(element.text.toLowerCase())) {
              final rect = element.boundingBox;
              found.add({
                'xPercent': rect.left / imgWidth,
                'yPercent': rect.top / imgHeight,
                'wPercent': rect.width / imgWidth,
                'hPercent': rect.height / imgHeight,
              });
            }
          }
        }
      }
    }
    return found;
  } catch (e) {
    debugPrint('TextRecognizer error: $e');
    return [];
  }
}

void dispose() => _recognizer.close();
